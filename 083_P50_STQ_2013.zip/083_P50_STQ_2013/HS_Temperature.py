"""DO NOT DELETE THIS FILE. This script opens command line and runs the named script.
This script must be located in the same directory as HeatSource_control.csv.
-i keeps command line open when the script is finished."""

import os

os.system('python -i PYrun_0_TE.py')
#os.system('python -i PYrun_1_SO.py')
#os.system('python -i PYrun_2_HY.py')
#os.system('python -i PYrun_3_SE.py')
